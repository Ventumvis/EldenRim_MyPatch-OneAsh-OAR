﻿Scriptname EldenRimVariantCast extends ActiveMagicEffect

; 2.3.4: identical logic to 2.3.3 (write -> cast B001 -> re-sync), plus logging.

Actor Property PlayerRef Auto
Spell Property CastSpellName Auto
FormList Property WarAshSlotList Auto
FormList Property VariantSlots Auto
Int Property Category Auto
Int Property Variant Auto

Event OnEffectStart(Actor Target, Actor Caster)
	If Caster == None || Category < 0 || Category >= 5 || Variant < 0 || Variant >= 6
		Return
	EndIf

	String profile = ResolveProfile()
	String listName = "rim_Slotlist" + profile
	Int sourceIndex = Category * 2
	If Variant > 0
		Int variantIndex = Category * 6 + Variant
		listName = "rim_SlotlistVariant" + variantIndex + "_" + profile
		sourceIndex = 0
	EndIf

	Float v0 = StorageUtil.FloatListGet(None, listName, sourceIndex)
	Float v1 = StorageUtil.FloatListGet(None, listName, sourceIndex + 1)

	Int activeIndex = Category * 2
	GlobalVariable activeSlot = WarAshSlotList.GetAt(activeIndex) as GlobalVariable
	GlobalVariable storedSlot = VariantSlots.GetAt((Category * 6 + Variant) * 2) as GlobalVariable
	If activeSlot != None
		activeSlot.SetValue(v0)
	EndIf
	If storedSlot != None
		storedSlot.SetValue(v0)
	EndIf

	activeSlot = WarAshSlotList.GetAt(activeIndex + 1) as GlobalVariable
	storedSlot = VariantSlots.GetAt((Category * 6 + Variant) * 2 + 1) as GlobalVariable
	If activeSlot != None
		activeSlot.SetValue(v1)
	EndIf
	If storedSlot != None
		storedSlot.SetValue(v1)
	EndIf


	If CastSpellName != None
		CastSpellName.Cast(Caster, None)
	EndIf
	Utility.Wait(0.25)
	SyncActiveSlots(listName, sourceIndex, Category * 2, Category * 6 + Variant)
EndEvent

String Function ResolveProfile()
	String profile = StorageUtil.GetStringValue(None, "Rim_CRList", "")
	If profile != ""
		Return profile
	EndIf
	If StorageUtil.FloatListCount(None, "rim_Slotlist2hw") >= 10
		Return "2hw"
	EndIf
	Return profile
EndFunction

Function SyncActiveSlots(String listName, Int sourceIndex, Int activeIndex, Int variantIndex)
	GlobalVariable activeSlot = WarAshSlotList.GetAt(activeIndex) as GlobalVariable
	GlobalVariable storedSlot = VariantSlots.GetAt(variantIndex * 2) as GlobalVariable
	If activeSlot != None
		activeSlot.SetValue(StorageUtil.FloatListGet(None, listName, sourceIndex))
	EndIf
	If storedSlot != None
		storedSlot.SetValue(StorageUtil.FloatListGet(None, listName, sourceIndex))
	EndIf
	activeSlot = WarAshSlotList.GetAt(activeIndex + 1) as GlobalVariable
	storedSlot = VariantSlots.GetAt(variantIndex * 2 + 1) as GlobalVariable
	If activeSlot != None
		activeSlot.SetValue(StorageUtil.FloatListGet(None, listName, sourceIndex + 1))
	EndIf
	If storedSlot != None
		storedSlot.SetValue(StorageUtil.FloatListGet(None, listName, sourceIndex + 1))
	EndIf
EndFunction
