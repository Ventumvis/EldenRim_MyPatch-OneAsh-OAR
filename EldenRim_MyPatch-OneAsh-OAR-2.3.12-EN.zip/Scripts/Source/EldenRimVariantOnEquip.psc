﻿Scriptname EldenRimVariantOnEquip extends ObjectReference

; 2.3.4: deterministic write-before-cast.
; The war-ash attack (B001 -> ERBWManager.BeginCast -> OAR) reads the active
; WarAshSlot globals. The old flow wrote the variant value from the
; enchantment's OnEffectStart, which runs AFTER the armor's OnEquipped already
; cast B001, so OAR saw the stale original value. This script runs ON the armor
; itself: it writes the variant (or original, for Variant 0) values FIRST and
; only then casts the same B001 spell CostBBSpell used to cast. One stack,
; no race. Replaces CostBBSpell on the variant armor (and on the overridden
; original Sila armor, to fix the same race in reverse).
; 2.3.9: traces removed, notifications kept.
; 2.3.8: notification shows [profile].
; 2.3.10: notifications removed.

Actor Property PlayerRef Auto
Spell Property CastSpellName Auto
FormList Property WarAshSlotList Auto
FormList Property VariantSlots Auto
Int Property Category Auto
Int Property Variant Auto

Event OnEquipped(Actor akActor)
	If akActor != PlayerRef
		Return
	EndIf
	If Category < 0 || Category >= 5 || Variant < 0 || Variant >= 6
		Return
	EndIf

	String profile = ResolveProfile()
	String listName = "rim_Slotlist" + profile
	Int sourceIndex = Category * 2
	If Variant > 0
		Int variantIndex = Category * 6 + Variant
		listName = "rim_SlotlistVariant" + variantIndex + "_" + profile
		sourceIndex = 0
	EndIf

	Float v0 = StorageUtil.FloatListGet(None, listName, sourceIndex)
	Float v1 = StorageUtil.FloatListGet(None, listName, sourceIndex + 1)
	Int count = StorageUtil.FloatListCount(None, listName)

	Int activeIndex = Category * 2
	GlobalVariable g0 = WarAshSlotList.GetAt(activeIndex) as GlobalVariable
	GlobalVariable g1 = WarAshSlotList.GetAt(activeIndex + 1) as GlobalVariable
	Float before0 = -9999.0
	Float before1 = -9999.0
	If g0 != None
		before0 = g0.GetValue()
		g0.SetValue(v0)
	EndIf
	If g1 != None
		before1 = g1.GetValue()
		g1.SetValue(v1)
	EndIf

	GlobalVariable s0 = VariantSlots.GetAt((Category * 6 + Variant) * 2) as GlobalVariable
	GlobalVariable s1 = VariantSlots.GetAt((Category * 6 + Variant) * 2 + 1) as GlobalVariable
	If s0 != None
		s0.SetValue(v0)
	EndIf
	If s1 != None
		s1.SetValue(v1)
	EndIf

	If CastSpellName != None
		CastSpellName.Cast(PlayerRef, None)
	Else
	EndIf
EndEvent

Event OnUnequipped(Actor akActor)
EndEvent

String Function ResolveProfile()
	String profile = StorageUtil.GetStringValue(None, "Rim_CRList", "")
	If profile != ""
		Return profile
	EndIf
	If StorageUtil.FloatListCount(None, "rim_Slotlist2hw") >= 10
		Return "2hw"
	EndIf
	Return profile
EndFunction
