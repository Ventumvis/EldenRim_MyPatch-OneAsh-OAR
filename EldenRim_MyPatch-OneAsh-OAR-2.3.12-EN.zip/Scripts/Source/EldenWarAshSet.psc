﻿Scriptname EldenWarAshSet extends ActiveMagicEffect

; 2.3.7: + timed double-fire guard (a second Set menu within 5 s of real time
; while the first is still open is dropped) + missing submenu treated as cancel.
; Otherwise identical to 2.3.5.
; 2.3.9: traces removed, notifications kept.
; 2.3.8: notification shows 1-based type and [profile].
; 2.3.10: notifications removed.

Actor Property PlayerRef Auto
Int Property WarAshExit = 5 Auto
Int Property WarAshID Auto
Message Property WarAshSetMessage1 Auto
Message Property WarAshSetMessage2 Auto
FormList Property WarAshSlotList Auto

Event OnEffectStart(Actor Target, Actor Caster)
	Float now = Utility.GetCurrentRealTime()
	Float mark = StorageUtil.GetFloatValue(None, "ERMy_SetMark", 0.0)
	Float busy = StorageUtil.GetFloatValue(None, "ERMy_SetBusy", 0.0)
	Float dT = now - mark
	If mark > 0.0 && dT >= 0.0 && dT < 5.0 && now < busy
		Return
	EndIf
	StorageUtil.SetFloatValue(None, "ERMy_SetMark", now)
	StorageUtil.SetFloatValue(None, "ERMy_SetBusy", now + 30.0)
	String profile = ResolveProfile()
	String originalList = "rim_Slotlist" + profile
	Utility.WaitMenuMode(1.0)

	Int category = WarAshSetMessage1.Show()
	If category >= 0 && category < 5 && category != WarAshExit
		FormList variantMessages = Game.GetFormFromFile(0x805, "EldenRim_MyPatch.esp") as FormList
		FormList variantSlots = Game.GetFormFromFile(0x842, "EldenRim_MyPatch.esp") as FormList
		Int variant = 0
		Bool cancelled = False
		If variantMessages == None || variantSlots == None
			cancelled = True
		Else
			Message variantMessage = variantMessages.GetAt(category) as Message
			If variantMessage != None
				variant = variantMessage.Show()
				If variant < 0 || variant >= 6
					cancelled = True
				EndIf
			Else
				cancelled = True
			EndIf
		EndIf

		If !cancelled
			Int hand = WarAshSetMessage2.Show()
			If hand != 1
				hand = 0
			EndIf
			Int originalSlotIndex = category * 2 + hand
			If variant == 0
				GlobalVariable originalSlot = WarAshSlotList.GetAt(originalSlotIndex) as GlobalVariable
				originalSlot.SetValueInt(WarAshID)
				StorageUtil.FloatListSet(None, originalList, originalSlotIndex, WarAshID as Float)
			Else
				Int variantIndex = category * 6 + variant
				GlobalVariable savedSlot = variantSlots.GetAt(variantIndex * 2 + hand) as GlobalVariable
				If savedSlot != None
					savedSlot.SetValueInt(WarAshID)
				EndIf
				String vList = "rim_SlotlistVariant" + variantIndex + "_" + profile
				If StorageUtil.FloatListCount(None, vList) < 2
					StorageUtil.FloatListResize(None, vList, 2, 0.0)
				EndIf
				StorageUtil.FloatListSet(None, vList, hand, WarAshID as Float)
				MagicEffect equipped = Game.GetFormFromFile(0x861 + variantIndex, "EldenRim_MyPatch.esp") as MagicEffect
				If equipped != None && PlayerRef != None && PlayerRef.HasMagicEffect(equipped)
					GlobalVariable activeSlot = WarAshSlotList.GetAt(originalSlotIndex) as GlobalVariable
					activeSlot.SetValueInt(WarAshID)
				EndIf
			EndIf
		EndIf
	EndIf

	StorageUtil.SetFloatValue(None, "ERMy_SetBusy", 0.0)
	Utility.Wait(0.3)
	Utility.WaitMenuMode(0.0)
EndEvent

String Function ResolveProfile()
	String profile = StorageUtil.GetStringValue(None, "Rim_CRList", "")
	If profile != ""
		Return profile
	EndIf
	If StorageUtil.FloatListCount(None, "rim_Slotlist2hw") >= 10
		Return "2hw"
	EndIf
	Return profile
EndFunction
