﻿Scriptname EldenRimVariantEquip extends ActiveMagicEffect

; 2.3.4: same slot sync as 2.3.3 (no OnEffectFinish reset), plus logging.
; Backup writer: the armor OnEquipped script (EldenRimVariantOnEquip) writes the
; same values deterministically before casting B001. Both writers agree, so
; their relative order no longer matters.

Actor Property PlayerRef Auto
FormList Property WarAshSlotList Auto
FormList Property VariantSlots Auto
MagicEffect Property MarkerEffect Auto
Int Property Category Auto
Int Property Variant Auto

Event OnEffectStart(Actor Target, Actor Caster)
	SyncSlots(Variant)
EndEvent

Function SyncSlots(Int sourceVariant)
	If Category < 0 || Category >= 5 || sourceVariant < 0 || sourceVariant >= 6
		Return
	EndIf

	String profile = ResolveProfile()
	String listName = "rim_Slotlist" + profile
	Int sourceIndex = Category * 2
	If sourceVariant > 0
		Int variantIndex = Category * 6 + sourceVariant
		listName = "rim_SlotlistVariant" + variantIndex + "_" + profile
		sourceIndex = 0
	EndIf

	Float v0 = StorageUtil.FloatListGet(None, listName, sourceIndex)
	Float v1 = StorageUtil.FloatListGet(None, listName, sourceIndex + 1)
	Int count = StorageUtil.FloatListCount(None, listName)

	Int activeIndex = Category * 2
	GlobalVariable activeSlot = WarAshSlotList.GetAt(activeIndex) as GlobalVariable
	GlobalVariable storedSlot = VariantSlots.GetAt((Category * 6 + sourceVariant) * 2) as GlobalVariable
	If activeSlot != None
		activeSlot.SetValue(v0)
	EndIf
	If storedSlot != None
		storedSlot.SetValue(v0)
	EndIf

	activeSlot = WarAshSlotList.GetAt(activeIndex + 1) as GlobalVariable
	storedSlot = VariantSlots.GetAt((Category * 6 + sourceVariant) * 2 + 1) as GlobalVariable
	If activeSlot != None
		activeSlot.SetValue(v1)
	EndIf
	If storedSlot != None
		storedSlot.SetValue(v1)
	EndIf

EndFunction

String Function ResolveProfile()
	String profile = StorageUtil.GetStringValue(None, "Rim_CRList", "")
	If profile != ""
		Return profile
	EndIf
	If StorageUtil.FloatListCount(None, "rim_Slotlist2hw") >= 10
		Return "2hw"
	EndIf
	Return profile
EndFunction
